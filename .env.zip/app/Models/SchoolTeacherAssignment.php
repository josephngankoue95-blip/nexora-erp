<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SchoolTeacherAssignment extends Model {
 protected $table = 'school_teacher_assignments';
 protected $fillable = ['company_id','teacher_id','subject_id','class_id','school_year_id','is_active'];
 protected $casts = ['is_active'=>'boolean'];
 public function teacher(){ return $this->belongsTo(SchoolTeacher::class, 'teacher_id'); } public function subject(){ return $this->belongsTo(SchoolSubject::class, 'subject_id'); }
}
