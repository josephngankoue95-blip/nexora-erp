<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Permission extends Model
{
    protected $fillable = [
        'name',
        'label',
        'module',
    ];

    public function rolePermissions(): HasMany
    {
        return $this->hasMany(
            RolePermission::class,
            'permission_id'
        );
    }

    public function userPermissions()
{
    return $this->hasMany(UserPermission::class);
}
}