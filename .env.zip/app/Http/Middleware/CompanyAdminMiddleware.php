<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CompanyAdminMiddleware
{
    public function handle(
        Request $request,
        Closure $next
    ): Response {

        $user = auth()->user();

        /*
        |--------------------------------------------------------------------------
        | UTILISATEUR NON CONNECTÉ
        |--------------------------------------------------------------------------
        */

        if (!$user) {
            return redirect()->route('login');
        }

        /*
        |--------------------------------------------------------------------------
        | SUPER ADMIN
        |--------------------------------------------------------------------------
        |
        | Le Super Admin possède son propre espace.
        |
        */

        if ($user->isSuperAdmin()) {
            return redirect()
                ->route('superadmin.dashboard')
                ->withErrors([
                    'access' =>
                        'Vous ne pouvez pas accéder à l’espace entreprise.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | RÔLES AUTORISÉS DANS L'ESPACE ENTREPRISE
        |--------------------------------------------------------------------------
        */

        $allowedRoles = [
            'companyadmin',
            'director',
            'manager',
            'seller',
            'cashier',
            'stock_manager',
            'accountant',
            'employee',
        ];

        if (!in_array($user->role, $allowedRoles, true)) {

            auth()->logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte ne possède pas de rôle valide.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ENTREPRISE OBLIGATOIRE
        |--------------------------------------------------------------------------
        */

        if (!$user->company_id) {

            auth()->logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte n’est associé à aucune entreprise.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | RÉCUPÉRATION DE L'ENTREPRISE
        |--------------------------------------------------------------------------
        */

        $company = $user->company;

        if (!$company) {

            auth()->logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre entreprise est introuvable.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ENTREPRISE ACTIVE
        |--------------------------------------------------------------------------
        */

        if (!$company->is_active) {

            auth()->logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre entreprise est actuellement inactive. '
                        . 'Veuillez contacter le Super Administrateur.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | COMPTE UTILISATEUR ACTIF
        |--------------------------------------------------------------------------
        */

        if (!$user->is_active) {

            auth()->logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte est désactivé. '
                        . 'Veuillez contacter l’administrateur de votre entreprise.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ACCÈS AUTORISÉ
        |--------------------------------------------------------------------------
        */

        return $next($request);
    }
}