<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Afficher la page de connexion.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Traiter la connexion.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        /*
        |--------------------------------------------------------------------------
        | AUTHENTIFICATION
        |--------------------------------------------------------------------------
        */

        $request->authenticate();

        $request->session()->regenerate();

        $user = $request->user();

        /*
        |--------------------------------------------------------------------------
        | COMPTE ACTIF
        |--------------------------------------------------------------------------
        */

        if (!$user->is_active) {

            Auth::logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte est désactivé. Veuillez contacter l’administrateur de votre entreprise.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | SUPER ADMIN
        |--------------------------------------------------------------------------
        */

        if ($user->isSuperAdmin()) {

            return redirect()
                ->route('superadmin.dashboard');
        }

        /*
        |--------------------------------------------------------------------------
        | RÔLES DE L'ESPACE ENTREPRISE
        |--------------------------------------------------------------------------
        */

        $companyRoles = [
            'companyadmin',
            'director',
            'manager',
            'seller',
            'cashier',
            'stock_manager',
            'accountant',
            'employee',
        ];

        /*
        |--------------------------------------------------------------------------
        | VÉRIFIER LE RÔLE
        |--------------------------------------------------------------------------
        */

        if (!in_array($user->role, $companyRoles, true)) {

            Auth::logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte ne possède pas de rôle valide.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ENTREPRISE OBLIGATOIRE
        |--------------------------------------------------------------------------
        */

        if (!$user->company_id) {

            Auth::logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre compte n’est associé à aucune entreprise.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | RÉCUPÉRER L'ENTREPRISE
        |--------------------------------------------------------------------------
        */

        $company = $user->company;

        if (!$company) {

            Auth::logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre entreprise est introuvable.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | VÉRIFIER SI L'ENTREPRISE EST ACTIVE
        |--------------------------------------------------------------------------
        */

        if (!$company->is_active) {

            Auth::logout();

            return redirect()
                ->route('login')
                ->withErrors([
                    'email' =>
                        'Votre entreprise est actuellement inactive. '
                        . 'Veuillez contacter le Super Administrateur.',
                ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ESPACE ENTREPRISE
        |--------------------------------------------------------------------------
        |
        | Tous les utilisateurs de l'entreprise arrivent sur le même
        | tableau de bord. Les permissions déterminent ensuite ce qu'ils
        | peuvent consulter ou modifier.
        |
        | Directeur :
        | - accès à l'espace entreprise
        | - consultation/supervision
        | - aucune modification selon ses permissions
        |
        */

        return redirect()
            ->route('company.modules.index');
    }

    /**
     * Déconnexion.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}