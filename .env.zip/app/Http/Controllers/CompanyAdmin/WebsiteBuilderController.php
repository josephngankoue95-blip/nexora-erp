<?php

namespace App\Http\Controllers\CompanyAdmin;

use App\Http\Controllers\Controller;
use App\Models\WebsitePage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Validation\Rule;

class WebsiteBuilderController extends Controller
{
    private function page(int $id): WebsitePage
    {
        $companyId = auth()->user()?->company_id;
        abort_unless($companyId, 403);

        return WebsitePage::query()
            ->where('company_id', $companyId)
            ->findOrFail($id);
    }

    public function edit(int $page): View
    {
        return view('company.website.builder.edit', ['page' => $this->page($page)]);
    }

    public function update(Request $request, int $page): RedirectResponse
    {
        $model = $this->page($page);

        $validated = $request->validate([
            'builder_content' => ['required', 'json', 'max:500000'],
            'status' => ['required', Rule::in(['draft', 'published'])],
        ]);

        $blocks = json_decode($validated['builder_content'], true);
        if (!is_array($blocks) || !array_is_list($blocks) || count($blocks) > 100) {
            return back()->withErrors(['builder_content' => 'Structure de page invalide (100 blocs maximum).']);
        }

        $allowed = ['hero', 'heading', 'text', 'image', 'button', 'label', 'columns', 'divider', 'gallery', 'video', 'cards', 'stats', 'quote', 'faq', 'cta', 'spacer'];
        $clean = [];
        foreach ($blocks as $block) {
            if (!is_array($block) || !in_array($block['type'] ?? null, $allowed, true)) {
                return back()->withErrors(['builder_content' => 'Un bloc de la page est invalide.']);
            }
            $data = $block['data'] ?? [];
            if (!is_array($data)) {
                return back()->withErrors(['builder_content' => 'Les données d’un bloc sont invalides.']);
            }
            $fields = ['title', 'subtitle', 'text', 'label', 'url', 'image', 'alt', 'background', 'color', 'left', 'right', 'third', 'image2', 'image3', 'height'];
            $safe = [];
            foreach ($fields as $field) {
                $value = $data[$field] ?? '';
                if (!is_string($value) || mb_strlen($value) > 5000) {
                    return back()->withErrors(['builder_content' => 'Une valeur de bloc est invalide.']);
                }
                $safe[$field] = $value;
            }
            foreach (['url', 'image', 'image2', 'image3'] as $field) {
                if ($safe[$field] !== '' && !$this->safeUrl($safe[$field])) {
                    return back()->withErrors(['builder_content' => 'URL non autorisée dans le bloc.']);
                }
            }
            if ($safe['background'] !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $safe['background'])) {
                return back()->withErrors(['builder_content' => 'Couleur de fond invalide.']);
            }
            if ($safe['color'] !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $safe['color'])) {
                return back()->withErrors(['builder_content' => 'Couleur de texte invalide.']);
            }
            $clean[] = ['type' => $block['type'], 'data' => $safe];
        }

        $model->builder_content = $clean;
        $model->status = $validated['status'];
        $model->published_at = $validated['status'] === 'published'
            ? ($model->published_at ?? now())
            : null;
        $model->save();

        return redirect()->route('company.website.builder.edit', $model->id)
            ->with('success', 'Personnalisation enregistrée.');
    }

    private function safeUrl(string $value): bool
    {
        if (str_starts_with($value, '/') && !str_starts_with($value, '//') && !str_contains($value, '\\')) {
            return !preg_match('/[\s<>"\']/', $value);
        }
        $parts = parse_url($value);
        return is_array($parts)
            && in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
            && !empty($parts['host']);
    }
}
