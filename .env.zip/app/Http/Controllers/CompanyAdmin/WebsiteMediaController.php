<?php
namespace App\Http\Controllers\CompanyAdmin;

use App\Http\Controllers\Controller;
use App\Models\WebsiteMedia;
use App\Models\WebsitePage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class WebsiteMediaController extends Controller
{
    /**
     * Identifier l'entreprise connectée.
     */
    private function companyId(): int
    {
        $companyId = auth()->user()?->company_id;

        abort_unless(
            $companyId,
            403,
            'Aucune entreprise associée à cet utilisateur.'
        );

        return (int) $companyId;
    }

    /**
     * Afficher les images de l'entreprise.
     */
    public function index()
    {
        $companyId = $this->companyId();

        $media = WebsiteMedia::query()
            ->where('company_id', $companyId)
            ->latest()
            ->paginate(18);

        return view(
            'company.website.media.index',
            compact('media')
        );
    }

    /**
     * Importer une nouvelle image.
     */
    public function store(Request $request)
    {
        $companyId = $this->companyId();

        $validated = $request->validate([
            'image' => [
                'required',
                'image',
                'mimes:jpg,jpeg,png,webp,gif',
                'max:5120',
            ],
        ]);

        // Le champ du formulaire est name="image".
        $file = $request->file('image');

        // Enregistrement dans le dossier de l'entreprise.
        $path = $file->store(
            'website/' . $companyId,
            'public'
        );

        if (!$path) {
            return back()->withErrors([
                'image' => "Impossible d'enregistrer l'image.",
            ]);
        }

        try {
            WebsiteMedia::create([
                'company_id' => $companyId,
                'original_name' => $file->getClientOriginalName(),
                'path' => $path,
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize(),
            ]);
        } catch (\Throwable $e) {

            // Nettoyer le fichier si la base échoue.
            Storage::disk('public')->delete($path);

            throw $e;
        }

        return back()->with(
            'success',
            'Image ajoutée à la médiathèque avec succès.'
        );
    }

    /**
     * Supprimer une image de l'entreprise.
     */
    public function destroy(int $media)
    {
        $companyId = $this->companyId();

        // Empêcher l'accès aux images des autres entreprises.
        $item = WebsiteMedia::query()
            ->where('company_id', $companyId)
            ->whereKey($media)
            ->firstOrFail();

        $path = $item->path;

        /**
         * Vérifier si l'image est utilisée
         * dans une page WebStudio.
         */
        $imageUrl = Storage::disk('public')->url($path);

        $isUsed = WebsitePage::query()
            ->where('company_id', $companyId)
            ->where(function ($query) use ($path, $imageUrl) {
                $query->where('content', 'like', '%' . $path . '%')
                    ->orWhere(
                        'content',
                        'like',
                        '%' . $imageUrl . '%'
                    );
            })
            ->exists();

        if ($isUsed) {
            return back()->withErrors([
                'image' =>
                    "Cette image est utilisée dans une page du site. " .
                    "Retirez-la de la page avant de la supprimer.",
            ]);
        }

        // Supprimer le fichier avant l'enregistrement.
        if (
            Storage::disk('public')->exists($path) &&
            !Storage::disk('public')->delete($path)
        ) {
            return back()->withErrors([
                'image' => "Impossible de supprimer le fichier.",
            ]);
        }

        $item->delete();

        return back()->with(
            'success',
            'Image supprimée avec succès.'
        );
    }
}