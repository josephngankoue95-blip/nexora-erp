{{-- WebStudio Builder V2 : rendu public sécurisé (aucun HTML libre). --}}
@foreach($builderBlocks as $block)
 @php
  $type = $block['type'] ?? '';
  $data = $block['data'] ?? [];
  $color = fn($key, $fallback) => preg_match('/^#[0-9a-fA-F]{6}$/', $data[$key] ?? '') ? $data[$key] : $fallback;
  $safeUrl = function ($value) {
   if (!is_string($value) || !$value) return null;
   if (str_starts_with($value, '/') && !str_starts_with($value, '//') && !preg_match('/[\\\\\s<>"\']/', $value)) return $value;
   $parts = parse_url($value);
   return is_array($parts) && in_array(strtolower($parts['scheme'] ?? ''), ['http','https'], true) && !empty($parts['host']) ? $value : null;
  };
 @endphp
 @if($type === 'hero' || $type === 'cta')
  <section class="wb-public-hero" style="background-color:{{ $color('background','#1e3a8a') }};color:{{ $color('color','#ffffff') }};@if($safeUrl($data['image'] ?? ''))background-image:linear-gradient(#0005,#0005),url('{{ $safeUrl($data['image']) }}');@endif">
   <div class="ws-container"><h1>{{ $data['title'] ?? '' }}</h1><p>{{ $data['subtitle'] ?? '' }}</p>
    @if($type === 'cta' && $safeUrl($data['url'] ?? ''))<a class="wb-public-button" href="{{ $safeUrl($data['url']) }}">{{ $data['label'] ?? 'Contactez-nous' }}</a>@endif
   </div>
  </section>
 @elseif($type === 'heading')
  <section class="ws-container wb-public-section"><h2 style="color:{{ $color('color','#172033') }}">{{ $data['title'] ?? '' }}</h2></section>
 @elseif($type === 'text')
  <section class="ws-container wb-public-section"><p style="color:{{ $color('color','#172033') }};white-space:pre-wrap">{{ $data['text'] ?? '' }}</p></section>
 @elseif($type === 'image')
  @if($safeUrl($data['image'] ?? ''))<section class="ws-container wb-public-section"><img class="wb-public-image" src="{{ $safeUrl($data['image']) }}" alt="{{ $data['alt'] ?? '' }}"></section>@endif
 @elseif($type === 'button')
  @if($safeUrl($data['url'] ?? ''))<section class="ws-container wb-public-section"><a class="wb-public-button" href="{{ $safeUrl($data['url']) }}" style="background:{{ $color('background','#2563eb') }};color:{{ $color('color','#ffffff') }}">{{ $data['label'] ?? 'En savoir plus' }}</a></section>@endif
 @elseif($type === 'label')
  <section class="ws-container wb-public-section"><span class="wb-public-label" style="background:{{ $color('background','#dbeafe') }};color:{{ $color('color','#1e40af') }}">{{ $data['label'] ?? '' }}</span></section>
 @elseif($type === 'columns')
  <section class="ws-container wb-public-section wb-public-columns"><div>{{ $data['left'] ?? '' }}</div><div>{{ $data['right'] ?? '' }}</div></section>
 @elseif($type === 'divider')
  <div class="ws-container wb-public-section"><hr></div>
 @elseif($type === 'gallery')
  <section class="ws-container wb-public-section wb-public-gallery">@foreach(['image','image2','image3'] as $key)@if($safeUrl($data[$key] ?? ''))<img src="{{ $safeUrl($data[$key]) }}" alt="{{ $data['alt'] ?? 'Galerie' }}" loading="lazy">@endif @endforeach</section>
 @elseif($type === 'cards' || $type === 'stats')
  <section class="ws-container wb-public-section"><h2>{{ $data['title'] ?? '' }}</h2><div class="wb-public-tiles">@foreach(['left','right','third'] as $key)<div class="wb-public-tile">{{ $data[$key] ?? '' }}</div>@endforeach</div></section>
 @elseif($type === 'quote')
  <section class="ws-container wb-public-section"><blockquote class="wb-public-quote"><p>“{{ $data['text'] ?? '' }}”</p><strong>{{ $data['title'] ?? '' }}</strong></blockquote></section>
 @elseif($type === 'faq')
  <section class="ws-container wb-public-section"><h2>{{ $data['title'] ?? 'FAQ' }}</h2><details class="wb-public-faq"><summary>{{ $data['left'] ?? '' }}</summary><p>{{ $data['right'] ?? '' }}</p></details></section>
 @elseif($type === 'video')
  @php
   $videoUrl = $safeUrl($data['url'] ?? '');
   $videoHost = $videoUrl ? strtolower(parse_url($videoUrl, PHP_URL_HOST) ?: '') : '';
   $videoPath = $videoUrl ? trim(parse_url($videoUrl, PHP_URL_PATH) ?: '', '/') : '';
   $videoId = null;
   if (in_array($videoHost, ['youtu.be','www.youtu.be'], true) && preg_match('/^[A-Za-z0-9_-]{11}$/', $videoPath)) $videoId = $videoPath;
   if (in_array($videoHost, ['youtube.com','www.youtube.com','m.youtube.com'], true)) {
    parse_str(parse_url($videoUrl, PHP_URL_QUERY) ?: '', $videoParams);
    if (preg_match('/^[A-Za-z0-9_-]{11}$/', $videoParams['v'] ?? '')) $videoId = $videoParams['v'];
   }
   $vimeoId = in_array($videoHost, ['vimeo.com','www.vimeo.com'], true) && preg_match('/^\d+$/', $videoPath) ? $videoPath : null;
  @endphp
  @if($videoId || $vimeoId)<section class="ws-container wb-public-section"><div class="wb-public-video"><iframe src="{{ $videoId ? 'https://www.youtube-nocookie.com/embed/'.$videoId : 'https://player.vimeo.com/video/'.$vimeoId }}" title="{{ $data['title'] ?? 'Vidéo' }}" loading="lazy" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div></section>@endif
 @elseif($type === 'spacer')
  <div aria-hidden="true" style="height:{{ min(400,max(8,(int)($data['height'] ?? 48))) }}px"></div>
 @endif
@endforeach
