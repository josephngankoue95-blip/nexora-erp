@extends('layouts.website')
@section('title', 'Personnaliser : ' . $page->title)
@section('page-title', 'Studio visuel · ' . $page->title)
@section('page-description', 'Construisez votre page, section par section.')
@section('content')
<div class="wb2" id="wb-builder">
 @if(session('success'))<div class="wb2-alert">{{ session('success') }}</div>@endif
 @if($errors->any())<div class="wb2-error">@foreach($errors->all() as $error)<p>{{ $error }}</p>@endforeach</div>@endif
 <form id="wb-form" method="POST" action="{{ route('company.website.builder.update', $page->id) }}">
 @csrf @method('PUT')
 <input type="hidden" name="builder_content" id="wb-json">
 <header class="wb2-bar">
  <a class="wb2-back" href="{{ route('company.website.pages.index') }}">← Pages</a>
  <span class="wb2-page-name">{{ $page->title }}</span>
  <div class="wb2-devices"><button type="button" class="active" data-device="desktop" title="Ordinateur">▣ <span>Ordinateur</span></button><button type="button" data-device="tablet" title="Tablette">▤</button><button type="button" data-device="mobile" title="Mobile">▯</button></div>
  <div class="wb2-actions"><button type="button" id="wb-undo" title="Annuler">↶</button><button type="button" id="wb-redo" title="Rétablir">↷</button><select name="status" aria-label="Statut"><option value="draft" @selected($page->status === 'draft')>Brouillon</option><option value="published" @selected($page->status === 'published')>Publiée</option></select><button class="wb2-save" type="submit">Enregistrer</button></div>
 </header>
 <div class="wb2-layout">
  <aside class="wb2-library"><div class="wb2-panel-head"><h2>Bibliothèque</h2><p>Ajoutez des éléments à votre page</p></div><input type="search" id="wb-search" placeholder="Rechercher un élément…" aria-label="Rechercher un élément"><div id="wb-categories"></div><p class="wb2-tip">Cliquez sur un élément ou glissez-le dans la page. Pour réorganiser, utilisez la poignée ⠿ des blocs.</p></aside>
  <main class="wb2-workspace"><div class="wb2-workspace-top"><span>APERÇU DE LA PAGE</span><span id="wb-device-label">100% · Ordinateur</span></div><div class="wb2-stage"><div id="wb-canvas" class="wb2-canvas" aria-label="Aperçu des blocs"></div></div><div class="wb2-foot">Glissez la poignée ⠿ pour déplacer un bloc. Les flèches ↑ ↓ restent disponibles.</div></main>
  <aside class="wb2-inspector" id="wb-properties"><h2>Propriétés</h2><p>Sélectionnez un élément.</p></aside>
 </div>
 </form>
</div>
<script type="application/json" id="wb-initial">@json($page->builder_content ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)</script>
@vite(['resources/css/website-builder.css', 'resources/js/website-builder.js'])
@endsection
