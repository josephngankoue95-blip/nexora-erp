document.addEventListener('DOMContentLoaded', () => {
 const root=document.getElementById('wb-builder');if(!root)return;
 const canvas=document.getElementById('wb-canvas'), inspector=document.getElementById('wb-properties'), json=document.getElementById('wb-json');
 const el=(tag,cls='',value)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n;};
 const safeColor=(s,f)=>/^#[a-f\d]{6}$/i.test(s||'')?s:f;
 const safeUrl=s=>{s=String(s||'').trim();return (/^\/(?!\/)[^\s<>"'\\]*$/.test(s)||/^https?:\/\/[a-z\d][^\s<>"']*$/i.test(s))?s:'';};
 const catalog=[
  ['Structure','hero','Bannière','▣',{title:'Bienvenue sur notre site',subtitle:'Découvrez nos services et notre savoir-faire.',image:'',background:'#1e3a8a',color:'#ffffff'}],
  ['Structure','columns','2 colonnes','▥',{left:'Votre contenu de gauche',right:'Votre contenu de droite'}],
  ['Structure','divider','Séparateur','━',{}],
  ['Contenu','heading','Titre','H₂',{title:'Votre titre ici',color:'#172033'}],
  ['Contenu','text','Paragraphe','☰',{text:'Présentez votre entreprise, votre offre ou vos valeurs.',color:'#172033'}],
  ['Contenu','label','Badge / Label','◉',{label:'NOUVEAUTÉ',background:'#dbeafe',color:'#1e40af'}],
  ['Contenu','button','Bouton','▰',{label:'En savoir plus',url:'/',background:'#2563eb',color:'#ffffff'}],
  ['Médias','image','Image','▧',{image:'',alt:'Description de l’image'}],
  ['Médias','gallery','Galerie','▦',{image:'',image2:'',image3:'',alt:'Galerie photo'}],
  ['Médias','video','Vidéo','▶',{url:'',title:'Découvrez notre vidéo'}],
  ['Sections','cards','Cartes services','▤',{title:'Nos services',left:'Premier service',right:'Deuxième service',third:'Troisième service'}],
  ['Sections','stats','Chiffres clés','▥',{title:'Notre impact',left:'100+',right:'10 ans',third:'24/7'}],
  ['Sections','quote','Témoignage','❞',{text:'Une expérience exceptionnelle avec cette entreprise.',title:'Client satisfait'}],
  ['Sections','faq','FAQ','?',{title:'Questions fréquentes',left:'Comment vous contacter ?',right:'Par téléphone ou via notre formulaire.'}],
  ['Sections','cta','Appel à l’action','➜',{title:'Un projet en tête ?',subtitle:'Échangeons sur vos besoins.',label:'Contactez-nous',url:'/contact',background:'#1e3a8a',color:'#ffffff'}],
  ['Sections','spacer','Espacement','↕',{height:'48'}]
 ];
 const meta=Object.fromEntries(catalog.map(x=>[x[1],{category:x[0],name:x[2],icon:x[3],defaults:x[4]}]));
 const fields={hero:[['title','Titre'],['subtitle','Sous-titre'],['image','URL image de fond'],['background','Fond'],['color','Texte']],columns:[['left','Colonne gauche'],['right','Colonne droite']],divider:[],heading:[['title','Titre'],['color','Couleur']],text:[['text','Paragraphe'],['color','Couleur']],label:[['label','Texte'],['background','Fond'],['color','Texte']],button:[['label','Libellé'],['url','Lien'],['background','Fond'],['color','Texte']],image:[['image','URL de l’image'],['alt','Texte alternatif']],gallery:[['image','Image 1'],['image2','Image 2'],['image3','Image 3'],['alt','Description']],video:[['url','URL vidéo (YouTube ou Vimeo)'],['title','Titre']],cards:[['title','Titre section'],['left','Carte 1'],['right','Carte 2'],['third','Carte 3']],stats:[['title','Titre section'],['left','Chiffre 1'],['right','Chiffre 2'],['third','Chiffre 3']],quote:[['text','Témoignage'],['title','Auteur']],faq:[['title','Titre'],['left','Question'],['right','Réponse']],cta:[['title','Titre'],['subtitle','Sous-titre'],['label','Bouton'],['url','Lien'],['background','Fond'],['color','Texte']],spacer:[['height','Hauteur (px)']]};
 let blocks=[];try{const v=JSON.parse(document.getElementById('wb-initial').textContent);if(Array.isArray(v))blocks=v.filter(b=>b&&meta[b.type]&&b.data&&typeof b.data==='object');}catch(e){}
 let selected=blocks.length?0:-1,undo=[],redo=[],device='desktop';
 let dragging=null;
 const dropMarker=el('div','wb2-drop-marker');dropMarker.textContent='Déposer ici';
 function clearDrag(){dragging=null;dropMarker.remove();root.classList.remove('wb2-is-dragging');canvas.querySelectorAll('.wb2-dragging').forEach(n=>n.classList.remove('wb2-dragging'));}
 function dropIndex(e){const items=[...canvas.querySelectorAll('.wb2-block')];for(let i=0;i<items.length;i++){const r=items[i].getBoundingClientRect();if(e.clientY<r.top+r.height/2)return i;}return items.length;}
 function placeMarker(i){const items=canvas.querySelectorAll('.wb2-block');if(items[i])canvas.insertBefore(dropMarker,items[i]);else canvas.append(dropMarker);}
 canvas.addEventListener('dragover',e=>{if(!dragging)return;e.preventDefault();e.dataTransfer.dropEffect=dragging.kind==='library'?'copy':'move';placeMarker(dropIndex(e));});
 canvas.addEventListener('drop',e=>{if(!dragging)return;e.preventDefault();const target=dropIndex(e),source=dragging;clearDrag();if(source.kind==='block'){const from=source.index;const to=target>from?target-1:target;if(to===from)return;snapshot();const [block]=blocks.splice(from,1);blocks.splice(to,0,block);selected=to;}else{const c=meta[source.type];if(!c)return;snapshot();blocks.splice(target,0,{type:source.type,data:{...c.defaults}});selected=target;}render();});
 document.addEventListener('dragend',clearDrag);
 canvas.addEventListener('dragleave',e=>{if(!canvas.contains(e.relatedTarget))dropMarker.remove();});
 const snapshot=()=>{undo.push(JSON.stringify(blocks));if(undo.length>50)undo.shift();redo=[];};
 const sync=()=>json.value=JSON.stringify(blocks);
 function tile(text){const t=el('div','wb2-tile');t.append(el('strong','',text));return t;}
 function img(url,alt){if(!safeUrl(url))return el('div','wb2-placeholder','Ajoutez une image depuis la médiathèque (URL publique)');const n=el('img');n.src=safeUrl(url);n.alt=alt||'';n.loading='lazy';return n;}
 function preview(b){const d=b.data||{},p=el('div','wb2-preview '+b.type);const add=(tag,text,cls='')=>{const n=el(tag,cls,text);p.append(n);return n;};
 switch(b.type){
 case 'hero':case 'cta':p.style.backgroundColor=safeColor(d.background,'#1e3a8a');p.style.color=safeColor(d.color,'#ffffff');if(safeUrl(d.image)){p.style.backgroundImage=`linear-gradient(#0005,#0005),url("${safeUrl(d.image)}")`;p.style.backgroundSize='cover';p.style.backgroundPosition='center';}add('h1',d.title||'Bannière');add('p',d.subtitle||'');if(b.type==='cta'){const n=add('span',d.label||'Découvrir','wb2-demo-btn');n.style.background='#fff';n.style.color='#1e3a8a';}break;
 case 'heading':add('h2',d.title||'Titre').style.color=safeColor(d.color,'#172033');break;
 case 'text':add('p',d.text||'Texte').style.color=safeColor(d.color,'#172033');break;
 case 'label':{const n=add('span',d.label||'Label','wb2-demo-label');n.style.background=safeColor(d.background,'#dbeafe');n.style.color=safeColor(d.color,'#1e40af');break;}
 case 'button':{const n=add('span',d.label||'Bouton','wb2-demo-btn');n.style.background=safeColor(d.background,'#2563eb');n.style.color=safeColor(d.color,'#ffffff');break;}
 case 'image':p.append(img(d.image,d.alt));break;
 case 'gallery':{const g=el('div','wb2-gallery');[d.image,d.image2,d.image3].forEach(u=>g.append(img(u,d.alt)));p.append(g);break;}
 case 'video':add('div',d.title||'Vidéo','wb2-placeholder');add('p','▶ Aperçu vidéo : ouvrez le site public pour la lecture');break;
 case 'columns':{const g=el('div','wb2-cols');g.append(tile(d.left||'Colonne gauche'),tile(d.right||'Colonne droite'));p.append(g);break;}
 case 'cards':case 'stats':{add('h2',d.title||'Section');const g=el('div',b.type==='cards'?'wb2-cards':'wb2-stats');[d.left,d.right,d.third].forEach(x=>g.append(tile(x||'Contenu')));p.append(g);break;}
 case 'quote':add('p','“'+(d.text||'Témoignage')+'”');add('strong',d.title||'Client');break;
 case 'faq':add('h2',d.title||'FAQ');add('strong',d.left||'Question');add('p',d.right||'Réponse');break;
 case 'spacer':p.style.height=Math.min(400,Math.max(8,Number(d.height)||48))+'px';p.style.background='#f8fafc';break;
 default:p.append(el('hr'));
 }return p;}
 function render(){canvas.replaceChildren();if(!blocks.length){const empty=el('div','wb2-empty');empty.append(el('div','', '✦'),el('strong','','Votre page est prête à être construite'),el('span','','Ajoutez une bannière ou choisissez un élément à gauche.'));canvas.append(empty);}
 blocks.forEach((b,i)=>{const item=el('div','wb2-block'+(selected===i?' selected':'')),head=el('div','wb2-block-head'),actions=el('div','wb2-block-tools');const grip=el('span','wb2-drag-handle','⠿');grip.title='Glisser pour déplacer ce bloc';grip.draggable=true;grip.setAttribute('role','button');grip.setAttribute('aria-label','Déplacer '+(meta[b.type]?.name||b.type));grip.addEventListener('dragstart',e=>{dragging={kind:'block',index:i};e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain','webstudio-block-'+i);root.classList.add('wb2-is-dragging');item.classList.add('wb2-dragging');});head.append(grip,el('strong','',meta[b.type]?.name||b.type));
 [['↑',()=>move(i,-1)],['↓',()=>move(i,1)],['⧉',()=>{snapshot();blocks.splice(i+1,0,JSON.parse(JSON.stringify(b)));selected=i+1;render();}],['✕',()=>remove(i)]].forEach(([label,fn])=>{const bt=el('button','',label);bt.type='button';bt.title=label==='⧉'?'Dupliquer':label==='✕'?'Supprimer':label;bt.addEventListener('click',e=>{e.stopPropagation();fn();});actions.append(bt);});head.append(actions);item.append(head,preview(b));item.addEventListener('click',()=>{selected=i;render();});canvas.append(item);});sync();renderInspector();}
 function move(i,step){const j=i+step;if(j<0||j>=blocks.length)return;snapshot();[blocks[i],blocks[j]]=[blocks[j],blocks[i]];selected=j;render();}
 function remove(i){snapshot();blocks.splice(i,1);selected=blocks.length?Math.min(i,blocks.length-1):-1;render();}
 function renderInspector(){inspector.replaceChildren(el('h2','','Propriétés'));if(selected<0||!blocks[selected]){inspector.append(el('p','wb2-subtitle','Sélectionnez un bloc pour le personnaliser.'));return;}
 const b=blocks[selected];inspector.append(el('p','wb2-subtitle',meta[b.type].name));const group=el('div','wb2-group');group.append(el('div','wb2-group-title','Contenu et apparence'));
 (fields[b.type]||[]).forEach(([key,title])=>{const label=el('label','',title),id='wb2-'+key;label.htmlFor=id;let input;const color=['color','background'].includes(key),long=['text','subtitle','left','right'].includes(key);input=el(long?'textarea':'input');input.id=id;if(!long)input.type=color?'color':'text';input.value=b.data[key]??(color?'#ffffff':'');input.addEventListener('focus',()=>{window.__wb2EditSnapshot=JSON.stringify(blocks);});input.addEventListener('change',()=>{if(window.__wb2EditSnapshot&&window.__wb2EditSnapshot!==JSON.stringify(blocks)){undo.push(window.__wb2EditSnapshot);redo=[];}window.__wb2EditSnapshot=null;});input.addEventListener('input',()=>{b.data[key]=input.value;sync();const item=canvas.children[selected];if(item)item.querySelector('.wb2-preview')?.replaceWith(preview(b));});group.append(label,input);});inspector.append(group);
 if(['image','hero','gallery'].includes(b.type))inspector.append(el('p','wb2-help','Copiez l’URL publique depuis WebStudio → Médiathèque.'));
 if(b.type==='video')inspector.append(el('p','wb2-help','Utilisez une URL YouTube ou Vimeo.'));
 const del=el('button','wb2-danger','Supprimer cet élément');del.type='button';del.addEventListener('click',()=>remove(selected));inspector.append(del);
 }
 function library(filter=''){const target=document.getElementById('wb-categories');target.replaceChildren();const groups=[...new Set(catalog.map(c=>c[0]))];groups.forEach(g=>{const items=catalog.filter(c=>c[0]===g&&(`${c[2]} ${c[1]}`).toLowerCase().includes(filter.toLowerCase()));if(!items.length)return;target.append(el('h3','wb2-category',g));const grid=el('div','wb2-items');items.forEach(c=>{const btn=el('button','wb2-item');btn.type='button';btn.draggable=true;btn.title='Cliquez ou glissez cet élément dans la page';btn.addEventListener('dragstart',e=>{dragging={kind:'library',type:c[1]};e.dataTransfer.effectAllowed='copy';e.dataTransfer.setData('text/plain','webstudio-library-'+c[1]);root.classList.add('wb2-is-dragging');});btn.append(el('span','wb2-item-icon',c[3]),el('span','wb2-item-name',c[2]));btn.addEventListener('click',()=>{snapshot();const at=selected<0?blocks.length:selected+1;blocks.splice(at,0,{type:c[1],data:{...c[4]}});selected=at;render();});grid.append(btn);});target.append(grid);});}
 document.getElementById('wb-search').addEventListener('input',e=>library(e.target.value));
 root.querySelectorAll('[data-device]').forEach(btn=>btn.addEventListener('click',()=>{device=btn.dataset.device;canvas.classList.toggle('tablet',device==='tablet');canvas.classList.toggle('mobile',device==='mobile');root.querySelectorAll('[data-device]').forEach(x=>x.classList.toggle('active',x===btn));document.getElementById('wb-device-label').textContent=device==='desktop'?'100% · Ordinateur':device==='tablet'?'Tablette':'Mobile';}));
 document.getElementById('wb-undo').addEventListener('click',()=>{if(!undo.length)return;redo.push(JSON.stringify(blocks));blocks=JSON.parse(undo.pop());selected=Math.min(selected,blocks.length-1);render();});
 document.getElementById('wb-redo').addEventListener('click',()=>{if(!redo.length)return;undo.push(JSON.stringify(blocks));blocks=JSON.parse(redo.pop());selected=Math.min(selected,blocks.length-1);render();});
 document.getElementById('wb-form').addEventListener('submit',sync);
 library();render();
});
