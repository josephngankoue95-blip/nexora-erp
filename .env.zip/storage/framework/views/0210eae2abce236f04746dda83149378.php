


<?php $__env->startSection('title', 'Paramètres de l’établissement'); ?>
<?php $__env->startSection('page-title', 'Paramètres de l’établissement'); ?>
<?php $__env->startSection('page-description', 'Identité, coordonnées et configuration de votre école'); ?>

<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/school-settings.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="school-settings-page">

    <?php if(session('success')): ?>
        <div class="ss-alert ss-success" role="status">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="ss-alert ss-error" role="alert">
            <strong>Veuillez corriger les erreurs suivantes :</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="ss-intro">
        <div>
            <span class="ss-eyebrow">CONFIGURATION SCOLAIRE</span>
            <h2>Informations de l'établissement</h2>
            <p>
                Personnalisez les informations officielles utilisées
                dans les documents de votre école.
            </p>
        </div>
        <span class="ss-company">
            Entreprise : <?php echo e($company->name); ?>

        </span>
    </div>

    <form
        method="POST"
        action="<?php echo e(route('company.school.settings.update')); ?>"
        enctype="multipart/form-data"
        class="ss-form"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <section class="ss-panel">
            <div class="ss-panel-heading">
                <span class="ss-step">01</span>
                <div>
                    <h3>Identité de l'établissement</h3>
                    <p>Informations administratives et officielles</p>
                </div>
            </div>

            <div class="ss-grid">
                <label class="ss-field ss-wide">
                    <span>Nom officiel de l'établissement *</span>
                    <input type="text" name="school_name"
                        value="<?php echo e(old('school_name', $settings->school_name)); ?>"
                        maxlength="255" required>
                </label>

                <label class="ss-field">
                    <span>Code de l'établissement</span>
                    <input type="text" name="school_code"
                        value="<?php echo e(old('school_code', $settings->school_code)); ?>">
                </label>

                <label class="ss-field">
                    <span>Type d'établissement</span>
                    <select name="school_type">
                        <option value="">Sélectionner</option>
                        <?php $__currentLoopData = [
                            'public' => 'Public',
                            'private' => 'Privé',
                            'other' => 'Autre'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"
                                <?php if(old('school_type', $settings->school_type) === $value): echo 'selected'; endif; ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="ss-field">
                    <span>Numéro d'autorisation</span>
                    <input type="text" name="authorization_number"
                        value="<?php echo e(old('authorization_number', $settings->authorization_number)); ?>">
                </label>

                <label class="ss-field">
                    <span>Devise de l'établissement</span>
                    <input type="text" name="motto"
                        value="<?php echo e(old('motto', $settings->motto)); ?>">
                </label>
            </div>
        </section>

        
        <section class="ss-panel">
            <div class="ss-panel-heading">
                <span class="ss-step">02</span>
                <div>
                    <h3>Logo et cachet</h3>
                    <p>Images utilisées dans les documents scolaires</p>
                </div>
            </div>

            <div class="ss-grid">
                <?php $__currentLoopData = [
                    'logo' => 'Logo de l’établissement',
                    'stamp' => 'Cachet officiel'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ss-upload">
                        <strong><?php echo e($label); ?></strong>

                        <div class="ss-preview">
                            <?php if($settings->{$field}): ?>
                                <img
                                    id="preview-<?php echo e($field); ?>"
                                    src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($settings->{$field})); ?>"
                                    alt="<?php echo e($label); ?>"
                                >
                            <?php else: ?>
                                <img
                                    id="preview-<?php echo e($field); ?>"
                                    alt="<?php echo e($label); ?>"
                                    hidden
                                >
                            <?php endif; ?>
                        </div>

                        <input
                            type="file"
                            name="<?php echo e($field); ?>"
                            accept=".jpg,.jpeg,.png,.webp"
                            data-preview="preview-<?php echo e($field); ?>"
                        >

                        <small>JPG, PNG ou WEBP — 2 Mo maximum.</small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        
        <section class="ss-panel">
            <div class="ss-panel-heading">
                <span class="ss-step">03</span>
                <div>
                    <h3>Coordonnées et localisation</h3>
                    <p>Adresse et moyens de contact</p>
                </div>
            </div>

            <div class="ss-grid">
                <?php $__currentLoopData = [
                    'country' => 'Pays',
                    'region' => 'Région',
                    'city' => 'Ville',
                    'address' => 'Adresse / Quartier',
                    'phone' => 'Téléphone',
                    'email' => 'Adresse email',
                    'website' => 'Site web'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="ss-field">
                        <span><?php echo e($label); ?> <?php echo e($field === 'country' ? '*' : ''); ?></span>
                        <input
                            type="<?php echo e($field === 'email' ? 'email' : ($field === 'website' ? 'url' : 'text')); ?>"
                            name="<?php echo e($field); ?>"
                            value="<?php echo e(old($field, $settings->{$field})); ?>"
                            <?php if($field === 'country'): ?> required <?php endif; ?>
                            <?php if($field === 'website'): ?> placeholder="https://exemple.com" <?php endif; ?>
                        >
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        
        <section class="ss-panel">
            <div class="ss-panel-heading">
                <span class="ss-step">04</span>
                <div>
                    <h3>Responsables de l'établissement</h3>
                    <p>Noms des responsables administratifs</p>
                </div>
            </div>

            <div class="ss-grid">
                <label class="ss-field">
                    <span>Directeur / Directrice</span>
                    <input type="text" name="director_name"
                        value="<?php echo e(old('director_name', $settings->director_name)); ?>">
                </label>

                <label class="ss-field">
                    <span>Proviseur / Principal</span>
                    <input type="text" name="principal_name"
                        value="<?php echo e(old('principal_name', $settings->principal_name)); ?>">
                </label>
            </div>
        </section>

        
        <section class="ss-panel">
            <div class="ss-panel-heading">
                <span class="ss-step">05</span>
                <div>
                    <h3>Configuration pédagogique</h3>
                    <p>Système éducatif et documents scolaires</p>
                </div>
            </div>

            <div class="ss-grid">
                <label class="ss-field">
                    <span>Système éducatif *</span>
                    <select name="academic_system" required>
                        <?php $__currentLoopData = [
                            'francophone' => 'Francophone',
                            'anglophone' => 'Anglophone',
                            'both' => 'Francophone et anglophone'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"
                                <?php if(old('academic_system', $settings->academic_system) === $value): echo 'selected'; endif; ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="ss-field">
                    <span>Barème de notation *</span>
                    <select name="grading_scale" required>
                        <?php $__currentLoopData = [20, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($scale); ?>"
                                <?php if((int) old('grading_scale', $settings->grading_scale) === $scale): echo 'selected'; endif; ?>>
                                Sur <?php echo e($scale); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="ss-field ss-wide">
                    <span>Texte de pied de page des bulletins</span>
                    <textarea name="bulletin_footer" rows="4"
                        maxlength="2000"><?php echo e(old('bulletin_footer', $settings->bulletin_footer)); ?></textarea>
                </label>
            </div>
        </section>

        <div class="ss-actions">
            <span>Les modifications concernent uniquement votre établissement.</span>
            <button type="submit" class="ss-submit">
                Enregistrer les paramètres
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/school-settings.js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.school', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\erp-saas\resources\views/company/school/settings/index.blade.php ENDPATH**/ ?>