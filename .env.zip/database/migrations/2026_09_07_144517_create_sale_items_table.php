<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sale_items', function (Blueprint $table) {
            $table->id();

            $table->foreignId('sale_id')
                ->constrained('sales')
                ->cascadeOnDelete();

            $table->foreignId('product_id')
                ->constrained('products')
                ->restrictOnDelete();

            $table->integer('quantity');

            $table->decimal('unit_price', 15, 2);

            $table->decimal('discount', 15, 2)->default(0);

            $table->decimal('total', 15, 2);

            $table->timestamps();

            $table->index(
                ['sale_id', 'product_id'],
                'sale_items_sale_product_index'
            );
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sale_items');
    }
};